To compile for 18.04, 19.04

comment out the following two line

#EXTRA_CFLAG=-DUBUNTU_21_04
#EXTRA_CFLAG=-DUBUNTU_20_04

To compile 20.04, uncomment out 20_04

#EXTRA_CFLAG=-DUBUNTU_21_04
EXTRA_CFLAG=-DUBUNTU_20_04


To compile for ubunto 21.04, uncoment out 21_04

EXTRA_CFLAG=-DUBUNTU_21_04
#EXTRA_CFLAG=-DUBUNTU_20_04

